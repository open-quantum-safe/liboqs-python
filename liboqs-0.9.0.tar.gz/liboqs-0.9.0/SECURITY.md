# Security Policy

## Supported Versions

We only support the most recent release.

| Version | Supported          |
| ------- | ------------------ |
| 0.8.0   | :white_check_mark: |
| < 0.8   | :x:                |

## Reporting a Vulnerability
Please follow [this information to report a vulnerability](https://openquantumsafe.org/liboqs/security.html#reporting-security-bugs).


