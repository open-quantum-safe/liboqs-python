// SPDX-License-Identifier: MIT

#ifndef CRYPTO_DECLASSIFY
#define CRYPTO_DECLASSIFY

#define crypto_declassify(x, y)

#endif
